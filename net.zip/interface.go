package net

import (
	"errors"
	"net"
	"strconv"
	"strings"
)

type Nic struct {
	Name string
	Ipv4 *net.IPNet
	Mac  net.HardwareAddr
}

func parseIp(s string) (*net.IPNet, error) {
	i := strings.Index(s, "/")
	if i < 0 {
		return nil, errors.New("the ip address should be xxx.xxx.xxx.xxx/24")
	}
	addr, mask := s[:i], s[i+1:]
	ip := net.ParseIP(addr)
	n, _ := strconv.Atoi(mask)
	if n > 32 || n < 0{
		return nil, errors.New("ipv4 address' mask should be upper than 0 and lower than 32")
	}
	m := net.CIDRMask(n, 8*4)
	return &net.IPNet{IP: ip, Mask: m}, nil
}

func GetIntfacesInfo() ([]Nic, error) {
	interfaces, err := net.Interfaces()
	if err != nil{
		return nil, err
	}
	var nics []Nic
	for i := 0; i < len(interfaces); i++{
		intF, err := net.InterfaceByName(interfaces[i].Name)
		if err != nil{
			return nil, err
		}
		address, _ := intF.Addrs()
		for _, v := range address{
			ipStr := v.String()
			if 4 != len(strings.Split(ipStr,".")) || nil == interfaces[i].HardwareAddr{
				continue
			}
			ipNet, _ := parseIp(ipStr)
			nic := Nic{
				Name: interfaces[i].Name,
				Ipv4: ipNet,
				Mac: interfaces[i].HardwareAddr,
			}
			nics = append(nics, nic)
		}
	}
	return nics, nil
}
